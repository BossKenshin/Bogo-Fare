<?php
require 'connect.php';

$fu = $_GET['typeFunction'];



if($fu == 'getFare'){
$tp = htmlspecialchars($_GET['tp']);
$fp = htmlspecialchars($_GET['fp']); 
$pp = htmlspecialchars($_GET['pp']);

// $sql = "SELECT fare from routes WHERE fromPlace = '$fp' AND toPlace = '$tp' AND passengerType = '$pp';";

$sql = "SELECT fare from routes WHERE fromPlace = '$tp' AND toPlace = '$fp' AND passengerType = '$pp'";
$result = $conn->query($sql);

if($result){

    while ($row = mysqli_fetch_array($result)) {

        echo $row['fare']; 

}

}
else{
    echo "WEW";
}



}

?>