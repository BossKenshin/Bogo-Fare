
function getfare(){


        var tp = document.getElementById("startplace").value;
        var e = document.getElementById("toplace");
        var value = e.options[e.selectedIndex].value;

        var es = document.getElementById("faree");
        var svalue = es.options[es.selectedIndex].value;

    //    alert("SELECT fare from routes WHERE fromPlace = '" + tp + "' AND toPlace = '" + value + "' AND passengerType = '" +svalue + "'");

       $.ajax({
        url: "./assets/js/function.php",
        dataType: 'script',
        type: "GET",
        data: {
            "typeFunction": 'getFare',
            "tp" : tp,
            "fp" : value,
            "pp" : svalue
        },
        success: function(data) {


                document.getElementById("valuefare").innerHTML = "YOUR FARE: ₱" + data;
        }

    })
    }
          
      

  

