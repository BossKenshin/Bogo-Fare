<?php
include 'connect.php';

$from = $_GET['fromplace'];
$to =  $_GET['toplace'];
$passenger =  $_GET['fareType'];
$fare = $_GET['fare'];

$sql = "INSERT INTO routes (fromPlace, toPlace, passengerType,fare) VALUES('$from','$to','$passenger','$fare')";

$result = mysqli_query($conn,$sql);

if($result){
    header("Location: admin.php"); 
}
else{
    die("Connection failed: " . mysqli_connect_error());

}

?>