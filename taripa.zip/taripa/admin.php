<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

    <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
        <form action="insert.php" method="get">
          <h4 class="text-light">From:</h4>
          <input class="form-control " type="text" name="fromplace" id="startplace">
          <br>
          <h4 class="text-center text-light">Vice Versa <i class="bi bi-arrow-down-up"></i></h4>
          <h4 class="text-light">To:</h4>
          <select class="form-select" name="toplace" id="">
            <option value="New Public Market">New Public Market</option>
            <option value="Gaisano">Gaisano</option>
            <option value="CBSAA">CBSAA</option>
          </select>
          <br>
          <h4 class="text-light">Passenger Type:</h4>

          <select class="form-select" name="fareType" id="faree">
            <option value="Regular">Regular</option>
            <option value="Student/Senior/PWD">Student/Senior/PWD</option>
          </select>
          <h4 class="text-light">Fare:</h4>
          <input type="form-control" type="number" name="fare" id="fare">
          <input type="submit" value="Submit">

          </form>
    </div>

</body>
</html>