-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2023 at 10:19 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tariff`
--

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `id` int(11) NOT NULL,
  `fromPlace` varchar(255) NOT NULL,
  `toPlace` varchar(255) NOT NULL,
  `passengerType` varchar(244) NOT NULL,
  `fare` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `fromPlace`, `toPlace`, `passengerType`, `fare`) VALUES
(1, 'Bogo Catholic Church', 'New Public Market', 'Regular', 15),
(2, 'Bogo Catholic Church', 'New Public Market', 'Student/Senior/PWD', 12),
(3, 'Bogo Catholic Chruch', 'Gaisano', 'Regular', 15),
(4, 'Bogo Catholic Chruch', 'Gaisano', 'Student/Senior/PWD', 12),
(5, 'Bogo Catholic Chruch', 'CBSAA', 'Regular', 15),
(6, 'Bogo Catholic Chruch', 'CBSAA', 'Student/Senior/PWD', 12),
(7, 'Buac', 'New Public Market', 'Regular', 20),
(8, 'Buac', 'New Public Market', 'Student/Senior/PWD', 16),
(9, 'Buac', 'Gaisano', 'Regular', 15),
(10, 'Buac', 'Gaisano', 'Student/Senior/PWD', 12),
(11, 'Buac', 'CBSAA', 'Regular', 15),
(12, 'Buac', 'CBSAA', 'Student/Senior/PWD', 12),
(13, 'Buac (New City Hall)', 'New Public Market', 'Regular', 23),
(14, 'Buac (New City Hall)', 'New Public Market', 'Student/Senior/PWD', 18),
(15, 'Buac (New City Hall)', 'Gaisano', 'Regular', 20),
(16, 'Buac (New City Hall)', 'Gaisano', 'Student/Senior/PWD', 16),
(17, 'Buac (New City Hall)', 'CBSAA', 'Regular', 20),
(18, 'Buac (New City Hall)', 'CBSAA', 'Student/Senior/PWD', 16),
(19, 'Buac (Buwangan)', 'New Public Market', 'Regular', 23),
(20, 'Buac (Buwangan)', 'New Public Market', 'Student/Senior/PWD', 18),
(21, 'Buac (Buwangan)', 'Gaisano', 'Regular', 20),
(22, 'Buac (Buwangan)', 'Gaisano', 'Student/Senior/PWD', 16),
(23, 'Buac (Buwangan)', 'CBSAA', 'Regular', 20),
(24, 'Buac (Buwangan)', 'CBSAA', 'Student/Senior/PWD', 16),
(25, 'Cogon (CBSAA)', 'New Public Market', 'Regular', 15),
(26, 'Cogon (CBSAA)', 'New Public Market', 'Student/Senior/PWD', 12),
(27, 'Cogon (CBSAA)', 'Gaisano', 'Regular', 15),
(28, 'Cogon (CBSAA)', 'Gaisano', 'Student/Senior/PWD', 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
